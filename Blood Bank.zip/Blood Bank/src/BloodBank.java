import java.util.Scanner;

public class BloodBank {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Welcome to the Blood Bank");
		System.out.println("**************************");
		System.out.printf("%-22s", "How old are you:");
		int age = input.nextInt();
				
		System.out.printf("%-22s","What is your weight: ");
		int weight = input.nextInt();
		System.out.println("**************************");
		
		if (age>= 18 && weight > 50) {
			System.out.println("You are ABLE to donate blood! Thank you");
		}
		else {
			System.out.println("You are UNABLE to donate blood! Thank you!");
		}
		
	}

}
